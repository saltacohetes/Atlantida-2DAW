{
    console.log("Examen de JavaScript");
}